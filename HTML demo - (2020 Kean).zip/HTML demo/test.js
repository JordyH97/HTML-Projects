var s1 = "24";
var s2 = "24";
var sum = s1 + s2;

console.log(sum);